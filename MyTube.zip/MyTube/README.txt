MyTube - lightweight WebView wrapper (Android 5.0+)

APK banane ke steps:
1. PC pe Android Studio install karo.
2. File > Open > is MyTube folder ko chuno. Gradle sync hone do (internet chahiye).
3. Build > Build APK(s). APK milega: app/build/outputs/apk/debug/app-debug.apk
4. APK ko tablet mein copy karke install karo (Unknown sources ON).

Agar video load na ho: tablet pe "Android System WebView" update karo.
